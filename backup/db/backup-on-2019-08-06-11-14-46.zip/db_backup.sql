#
# TABLE STRUCTURE FOR: blog
#

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `id_blog` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `content` text NOT NULL,
  `date` varchar(50) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `image` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `is_active` int(1) NOT NULL,
  PRIMARY KEY (`id_blog`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `blog` (`id_blog`, `title`, `content`, `date`, `slug`, `image`, `author`, `is_active`) VALUES (12, 'Cara berjualan yang benar', 'adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.</p></div><div xss=removed><h2 xss=removed>Mengapa kita menggunakannya?</h2><p xss=removed>Sudah merupakan fakta bahwa seorang pembaca akan terpengaruh oleh isi tulisan dari sebuah halaman saat ia melihat tata letaknya. Maksud penggunaan Lorem Ipsum adalah karena ia kurang lebih memiliki penyebaran huruf yang normal, ketimbang menggunakan kalimat seperti \"Bagian isi disini, bagian isi disini\", sehingga ia seolah menjadi naskah Inggris yang bisa dibaca. Banyak paket Desktop Publishing dan editor situs web yang kini menggunakan Lorem Ipsum sebagai contoh teks. Karenanya pencarian terhadap kalimat \"Lorem Ipsum\" akan berujung pada banyak situs web yang masih dalam tahap pengembangan. Berbagai versi juga telah berubah dari tahun ke tahun, kadang karena tidak sengaja, kadang karena disengaja (misalnya karena dimasukkan unsur humor atau semacamnya)</p></div><p><br xss=removed></p><div xss=removed><h2 xss=removed>Dari mana asalnya?</h2><p xss=removed>Tidak seperti anggapan banyak orang, Lorem Ipsum bukanlah teks-teks yang diacak. Ia berakar dari sebuah naskah sastra latin klasik dari era 45 sebelum masehi, hingga bisa dipastikan usianya telah mencapai lebih dari 2000 tahun. Richard McClintock, seorang professor Bahasa Latin dari Hampden-Sidney College di Virginia, mencoba mencari makna salah satu kata latin yang dianggap paling tidak jelas, yakni consectetur, yang diambil dari salah satu bagian Lorem Ipsum. Setelah ia mencari maknanya di di literatur klasik, ia mendapatkan sebuah sumber yang tidak bisa diragukan. Lorem Ipsum berasal dari bagian 1.10.32 dan 1.10.33 dari naskah \"de Finibus Bonorum et Malorum\" (Sisi Ekstrim dari Kebaikan dan Kejahatan) karya Cicero, yang ditulis pada tahun 45 sebelum masehi. BUku ini adalah risalah dari teori etika yang sangat terkenal pada masa Renaissance. Baris pertama dari Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", berasal dari sebuah baris di bagian 1.10.32.</p><p xss=removed>Bagian standar dari teks Lorem Ipsum yang digunakan sejak tahun 1500an kini di reproduksi kembali di bawah ini untuk mereka yang tertarik. Bagian 1.10.32 dan 1.10.33 dari \"de Finibus Bonorum et Malorum\" karya Cicero juga di reproduksi persis seperti bentuk aslinya, diikuti oleh versi bahasa Inggris yang berasal dari terjemahan tahun 1914 oleh H. Rackham.</p></div><div xss=removed><h2 xss=removed>Dari mana saya bisa mendapatkannya?</h2><p xss=removed>Ada banyak variasi tulisan Lorem Ipsum yang tersedia, tapi kebanyakan sudah mengalami perubahan bentuk, entah karena unsur humor atau kalimat yang diacak hingga nampak sangat tidak masuk akal. Jika anda ingin menggunakan tulisan Lorem Ipsum, anda harus yakin tidak ada bagian yang memalukan yang tersembunyi di tengah naskah tersebut. Semua generator Lorem Ipsum di internet cenderung untuk mengulang bagian-bagian tertentu. Karena itu inilah generator pertama yang sebenarnya di internet. Ia menggunakan kamus perbendaharaan yang terdiri dari 200 kata Latin, yang digabung dengan banyak contoh struktur kalimat untuk menghasilkan Lorem Ipsun yang nampak masuk akal. Karena itu Lorem Ipsun yang dihasilkan akan selalu bebas dari pengulangan, unsur humor yang sengaja dimasukkan, kata yang tidak sesuai dengan karakteristiknya dan lain sebagainya.</p>', '1564151954', 'cara-berjualan-yang-benar.html', '417b2f2e58ad2dc0d5f3ed2a673e649f.jpg', 'Ahmad Qomaini', 1);
INSERT INTO `blog` (`id_blog`, `title`, `content`, `date`, `slug`, `image`, `author`, `is_active`) VALUES (18, 'kawinan', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore architecto sed odit! Sed ullam, repellat quod magni! Ipsam veritatis aspernatur suscipit labore ad. Reiciendis eius tempora quaerat, reprehenderit magni similique.', '1564158506', 'kawinan.html', '57c39737216d47c7b482c509df21fd6a.jpg', 'Ahmad Qomaini', 1);
INSERT INTO `blog` (`id_blog`, `title`, `content`, `date`, `slug`, `image`, `author`, `is_active`) VALUES (21, 'Tes positngannnnnn fdfgsedfas dfsfsd sdfdsf', '&lt;p&gt;fsfew v gf gwe vterergevg egre bve ev  reterv erv terr re tervvter retervtere&lt;/p&gt;', '1564169527', 'tes-positngannnnnn.html', 'c3317e8ac550a19e47a7c92c68cb8840.jpeg', 'Ahmad Qomaini', 1);
INSERT INTO `blog` (`id_blog`, `title`, `content`, `date`, `slug`, `image`, `author`, `is_active`) VALUES (22, 'Tes Posting Dari Hp', '&lt;p&gt;Aku sudah mencoba untuk membuat content tidak apa2, tapi apa Kan days content nya jadi berantakan.&lt;/p&gt;', '1564171664', 'tes-posting-dari-hp.html', 'a69510abfd114896fdca2cbc95594d12.jpg', 'Ahmad Qomaini', 1);


#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(1) NOT NULL,
  `protocol` varchar(20) NOT NULL,
  `host` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `port` int(4) NOT NULL,
  `type` enum('html','text','','') NOT NULL,
  `charset` varchar(20) NOT NULL,
  `newline` varchar(20) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `sistem_email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `email_config` (`id`, `protocol`, `host`, `username`, `password`, `port`, `type`, `charset`, `newline`, `admin_email`, `sistem_email`) VALUES (1, 'smtp', 'ssl://smtp.googlemail.com', 'printcloud91@gmail.com', '9b728c647d361352c031d6dfb485b85790011ecadfd5c271cb7e1235820e93e5568735687b9af278adcc350e3086517733b8', 465, 'html', 'utf-8', '\\r\\n', 'beniepedia@gmail.com', 'no-replay@id-mjp.com');


#
# TABLE STRUCTURE FOR: tb_category_post
#

DROP TABLE IF EXISTS `tb_category_post`;

CREATE TABLE `tb_category_post` (
  `category_post_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_post_name` varchar(100) NOT NULL,
  `category_post_slug` varchar(100) NOT NULL,
  PRIMARY KEY (`category_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tb_category_post` (`category_post_id`, `category_post_name`, `category_post_slug`) VALUES (1, 'Tips dan trick tipsss', 'tips-dan-trick-tipsss');
INSERT INTO `tb_category_post` (`category_post_id`, `category_post_name`, `category_post_slug`) VALUES (2, 'Membela diri', 'membela-diri');
INSERT INTO `tb_category_post` (`category_post_id`, `category_post_name`, `category_post_slug`) VALUES (5, 'Beljar membaca', 'beljar-membaca');
INSERT INTO `tb_category_post` (`category_post_id`, `category_post_name`, `category_post_slug`) VALUES (6, 'Membaca dan menulis', 'membaca-dan-menulis');
INSERT INTO `tb_category_post` (`category_post_id`, `category_post_name`, `category_post_slug`) VALUES (7, 'Cara menjadi yang terbaik', 'cara-menjadi-yang-terbaik');


#
# TABLE STRUCTURE FOR: tb_general_set
#

DROP TABLE IF EXISTS `tb_general_set`;

CREATE TABLE `tb_general_set` (
  `general_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `general_set_fb` enum('1','0') NOT NULL DEFAULT '0' COMMENT '1:on, 0:off',
  `general_set_google` enum('1','0') NOT NULL DEFAULT '0' COMMENT '1:on, 0:off',
  `general_set_blog` enum('1','0') NOT NULL DEFAULT '0' COMMENT '1:on, 0:off',
  `general_set_ig` enum('1','0') DEFAULT '0' COMMENT '1:on, 0:off',
  `general_set_captcha` enum('1`','0') NOT NULL DEFAULT '0' COMMENT '1:on, 0:off',
  PRIMARY KEY (`general_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tb_general_set` (`general_set_id`, `general_set_fb`, `general_set_google`, `general_set_blog`, `general_set_ig`, `general_set_captcha`) VALUES (1, '0', '0', '0', '1', '0');


#
# TABLE STRUCTURE FOR: tb_inbox
#

DROP TABLE IF EXISTS `tb_inbox`;

CREATE TABLE `tb_inbox` (
  `inbox_id` int(11) NOT NULL AUTO_INCREMENT,
  `inbox_name` varchar(100) DEFAULT NULL,
  `inbox_email` text,
  `inbox_phone` varchar(20) DEFAULT NULL,
  `inbox_subject` varchar(50) DEFAULT NULL,
  `inbox_message` text,
  `inbox_created` varchar(100) DEFAULT NULL,
  `inbox_status` enum('1','0','','') NOT NULL DEFAULT '0' COMMENT '1=read,0=unread',
  PRIMARY KEY (`inbox_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (1, 'Ahmad Qomaini', 'ahmadqomaini1991@gmail.com', '082174416077', 'Tes aja bang', 'ini hanya pesan dummy', '1564938887', '1');
INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (2, 'Ahmad Qomaini', 'ahmadqomaini@yahoo.com', '082174416077', 'Jangan lah', 'dgdgnfbfd dfgfd dfgfd dff', '1565024956', '1');
INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (3, 'Ahmad Qomaini', 'ahmadqomaini@yahoo.com', '082174416077', 'Jangan lah', 'ewr wewef ewf ew f', '1565024970', '0');
INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (4, 'tess', 'ewrwe2@GMAIL.COM', '082174416077', 'fefe', 'fefewfew ef  fewwe', '1565024985', '0');
INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (5, 'Ahmad Qomaini', 'ahmadqomaini@yahoo.com', '082174416077', 'ewfewfewf', 'f fe fefew efdsfdsfsfds sdfds', '1565025001', '0');
INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (6, 'tess', 'admin@admin.com', '082174416077', 'ewfewfewf', 'fdsfds  dsdvdsfdsvdsdsv', '1565025018', '1');
INSERT INTO `tb_inbox` (`inbox_id`, `inbox_name`, `inbox_email`, `inbox_phone`, `inbox_subject`, `inbox_message`, `inbox_created`, `inbox_status`) VALUES (7, 'Ahmad Qomaini', 'diki@gmail.com', '082174416077', 'Belajar membaca', 'fdfds dsf dsfsd sdfsd', '1565025046', '1');


#
# TABLE STRUCTURE FOR: tb_sosial_api
#

DROP TABLE IF EXISTS `tb_sosial_api`;

CREATE TABLE `tb_sosial_api` (
  `api_id` int(11) NOT NULL AUTO_INCREMENT,
  `api_fb_id` varchar(100) DEFAULT NULL,
  `api_fb_key` varchar(100) DEFAULT NULL,
  `api_google_id` varchar(100) DEFAULT NULL,
  `api_google_key` varchar(100) DEFAULT NULL,
  `api_captcha_sitekey` varchar(100) DEFAULT NULL,
  `api_captcha_serverkey` varchar(100) DEFAULT NULL,
  `api_ig_token` varchar(100) DEFAULT NULL,
  `api_ig_count` int(2) DEFAULT NULL,
  PRIMARY KEY (`api_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tb_sosial_api` (`api_id`, `api_fb_id`, `api_fb_key`, `api_google_id`, `api_google_key`, `api_captcha_sitekey`, `api_captcha_serverkey`, `api_ig_token`, `api_ig_count`) VALUES (1, '2430830390480285', '5d85b7fd4a9c041b4b0cfb5c594dc99d', NULL, NULL, NULL, NULL, '10016460928.640eb2b.4a170bed44784d40b2027b6daa0ea773', 8);


#
# TABLE STRUCTURE FOR: tb_tags_post
#

DROP TABLE IF EXISTS `tb_tags_post`;

CREATE TABLE `tb_tags_post` (
  `tags_post_id` int(11) NOT NULL AUTO_INCREMENT,
  `tags_post_name` varchar(100) NOT NULL,
  PRIMARY KEY (`tags_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tb_tags_post` (`tags_post_id`, `tags_post_name`) VALUES (1, 'Teknologi');
INSERT INTO `tb_tags_post` (`tags_post_id`, `tags_post_name`) VALUES (2, 'Otomotive');
INSERT INTO `tb_tags_post` (`tags_post_id`, `tags_post_name`) VALUES (4, 'Dunia');
INSERT INTO `tb_tags_post` (`tags_post_id`, `tags_post_name`) VALUES (5, 'Balapan');
INSERT INTO `tb_tags_post` (`tags_post_id`, `tags_post_name`) VALUES (6, 'Komputer');
INSERT INTO `tb_tags_post` (`tags_post_id`, `tags_post_name`) VALUES (7, 'Pendidikan');


#
# TABLE STRUCTURE FOR: tb_visitors
#

DROP TABLE IF EXISTS `tb_visitors`;

CREATE TABLE `tb_visitors` (
  `visit_id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_ip` varchar(50) NOT NULL,
  `visit_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `visit_browser` varchar(50) NOT NULL,
  `visit_platform` varchar(50) NOT NULL,
  PRIMARY KEY (`visit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (25, '192.168.88.254', '2019-08-02 03:03:54', 'Chrome', 'Android');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (26, '192.1.1.1', '2019-08-02 03:05:29', 'Chrome', 'Windows XP');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (27, '192.1.1.2', '2019-08-02 03:06:25', 'Firefox', 'Windows 7');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (28, '192.1.1.3', '2019-08-02 03:07:14', 'Internet Explorer', 'Windows 8.1');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (29, '192.1.1.4', '2019-08-02 03:07:53', 'Opera', 'Windows 8');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (30, '192.1.1.5', '2019-08-02 03:08:25', 'Opera', 'Windows 10');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (31, '192.1.1.6', '2019-08-02 03:09:24', 'Safari', 'iOS');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (32, '::1', '2019-08-02 03:09:59', 'Chrome', 'Linux');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (33, '192.168.88.246', '2019-08-02 23:01:08', 'Chrome', 'Windows 10');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (34, '192.168.88.246', '2019-08-03 00:52:58', 'Chrome', 'Windows 10');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (35, '::1', '2019-08-03 00:53:31', 'Chrome', 'Linux');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (36, '192.168.88.254', '2019-08-03 01:40:00', 'Chrome', 'Android');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (37, '::1', '2019-08-04 22:59:15', 'Chrome', 'Linux');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (38, '::1', '2019-08-05 00:13:59', 'Chrome', 'Linux');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (39, '192.168.88.254', '2019-08-05 11:11:03', 'Chrome', 'Android');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (40, '::1', '2019-08-06 00:06:59', 'Chrome', 'Linux');
INSERT INTO `tb_visitors` (`visit_id`, `visit_ip`, `visit_date`, `visit_browser`, `visit_platform`) VALUES (41, '192.168.88.254', '2019-08-06 09:50:33', 'Chrome', 'Android');


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id_role` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `user_role` (`id_role`, `role`) VALUES (1, 'Administrator');
INSERT INTO `user_role` (`id_role`, `role`) VALUES (2, 'Member');


#
# TABLE STRUCTURE FOR: user_token
#

DROP TABLE IF EXISTS `user_token`;

CREATE TABLE `user_token` (
  `id_token` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id_token`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_provider` enum('facebook','google','twitter','local') NOT NULL DEFAULT 'local',
  `oauth_uid` varchar(50) DEFAULT NULL,
  `ipaddr` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` text,
  `image` varchar(150) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id_user`, `oauth_provider`, `oauth_uid`, `ipaddr`, `name`, `date`, `phone`, `email`, `password`, `gender`, `address`, `image`, `role_id`, `is_active`, `date_created`, `last_login`) VALUES (21, 'local', '', '::1', 'Ahmad Qomaini', '1991-01-07', '0821744160777', 'ahmadqomaini@yahoo.com', '$2y$10$vi0DkAr4MwDtv0Q5kapZB.0D8oCOM4GZ2q0PDay.MoMRzALdEEaz.', 'laki-laki', 'Jl. Parit dua 2 laut', 'ahmad_qomaini-1565023039.jpeg', 1, 1, 1562853373, 1565064857);
INSERT INTO `users` (`id_user`, `oauth_provider`, `oauth_uid`, `ipaddr`, `name`, `date`, `phone`, `email`, `password`, `gender`, `address`, `image`, `role_id`, `is_active`, `date_created`, `last_login`) VALUES (22, 'local', NULL, '192.168.88.254', 'Ahmad Qomaini srg', '0000-00-00', '082174416077', 'beniepay@gmail.com', '$2y$10$Ny9bdsO5XyjslvnLwPgawOnht9qnJ4ra5HiE6sEFJcGNJ5l4MnTl2', 'perempuan', '', 'default.jpg', 2, 1, 1564693594, 1564693653);


#
# TABLE STRUCTURE FOR: web_config
#

DROP TABLE IF EXISTS `web_config`;

CREATE TABLE `web_config` (
  `id` int(1) NOT NULL,
  `site_name` varchar(100) DEFAULT NULL,
  `site_alias` varchar(50) DEFAULT NULL,
  `site_description` text,
  `site_author` varchar(50) DEFAULT NULL,
  `site_logo_header` varchar(100) DEFAULT NULL,
  `site_handphone` varchar(20) DEFAULT NULL,
  `site_whatsapp_1` varchar(20) DEFAULT NULL,
  `site_whatsapp_2` varchar(20) DEFAULT NULL,
  `site_address` text,
  `site_fb` varchar(150) DEFAULT NULL,
  `site_instagram` varchar(150) DEFAULT NULL,
  `site_twitter` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `web_config` (`id`, `site_name`, `site_alias`, `site_description`, `site_author`, `site_logo_header`, `site_handphone`, `site_whatsapp_1`, `site_whatsapp_2`, `site_address`, `site_fb`, `site_instagram`, `site_twitter`) VALUES (0, 'ID-MJPARFUME', 'ID-MJP.com', 'Situs resmi yang menjual produk original dari MJParfume', 'BeniePedia', 'logo-id-mjparfume-23.png', '+6282174416077', '+6282174416077', '+6282174416077', 'Jln. sederhana no . 10', '', '', '');


